# PLAN — Family Watch Club channel (repo-first, like the tarot channel)

## DIRECTION UPDATE (Fernando, Aug 11 late session — supersedes conflicting bits below)

- **Name: "Family Watch Club"** (working). Drop "kids" language everywhere in
  this project's public surfaces — COPPA posture: parent-facing service,
  static no-collection kid surfaces, never "directed at children" branding.
  (kids-stories-club repo rename = open decision, don't do unilaterally.)
- **Merge into the existing recursive.eco channels architecture** rather than
  a standalone thing — one channel (slug idea: `family-watch`), everything to
  the commons. Parents fork/copy grammars into personal channels (north-star
  P1 spin-out + P2 non-tech creators + P4 commons).
- **Two-zone architecture, explicit in the UI:**
  - **HARBOR (kiosk zone)**: self-contained, zero external links, zero
    accounts — books, karaoke audiobooks as thumbnails (pull from
    kids-stories-club public repo), bedtime storybook, viewers with `?kiosk`.
    Kid can be alone here. This is the homepage's default face.
  - **LAUNCHPAD (parents' page, separate page)**: personal channels list
    (grammars + slugs), main channel, extension download/setup, course, and
    the family's purchased-video links — everything that "goes off to wander
    on the internet" lives ONLY here, visibly marked.
- **Purchased-video URLs = two layers**: commons grammars carry only generic
  official links; the family's own copy URL (e.g. their YouTube purchase) is
  stored locally (extension settings / launchpad localStorage — no accounts)
  or in their personal channel fork. Launchpad renders a big WATCH button per
  movie from the saved URL, with the companion set pre-selected.
- Timing: Fernando's weekly credits reset window — big build should happen
  by TOMORROW (Aug 12). Session resumes within the hour.


Written Aug 11 2026 at end-of-session; execute in a fresh session. Read
`recursive-recording/legends-of-the-pacific/CLAUDE.md` first (project spine, IP
line, working agreements). Ask before anything goes public.

## Goal

Turn the family film club into a recursive.eco channel + public repo +
homepage + course, modeled on the tarot channel and the github-first loop
(source_of_truth is CHANNEL-level; see memory `recursive-eco-github-first-loop-shipped`).

## Current state (already done)

- Extension v1.2.0 at `GitHub/movie-companion/` (local only, not a repo yet):
  quizzes, Movie+Theme dropdowns, Fetch-URL + Refresh-from-source, eye icon,
  grammar import (splits by metadata.lens), host permissions for
  recursive.eco + raw.githubusercontent.com.
- Moana grammar PRIVATE on recursive.eco: `2a0b8085-cdd3-4a0d-b7d7-8c07d880a366`
  (17 items: 10 discussion + 7 repair; metadata.time/lens/movie/quiz).
- Legends of the Pacific book merged into recursive-kids-stories-club (PR #8).
- Legends grammar PRIVATE with TTS karaoke: `a2f5eb14-8a69-41f0-9233-c01c39549f85`.
- Bundled prompt JSONs in extension = duplicate of grammar content; grammar is
  master; regenerate bundled files from grammars when content changes.

## Token question — RESOLVED

Manual API token is only needed for PRIVATE grammars
(`/api/gpt/grammars/{id}` + Bearer, generated at flow.recursive.eco/account —
rotating invalidates the old one). Once grammars are public or repo-first:
- Public grammar, no auth: `https://flow.recursive.eco/api/tarot-channel/decks/{id}`
  (type-agnostic; returns items as `cards` — extension already unwraps this).
- Repo-first, no auth: raw.githubusercontent.com URL of grammar.json —
  extension already has host permission. **This is the channel default.**

## Aug 11 late additions (after site went live)

- DONE: kids.recursive.eco Harbor card; restyle to channels design family
  (theme.css tokens from recursive-tarot: warm paper, Fraunces, gold accent,
  purple wayfinding on recursive.eco links; harbor=green / launchpad=purple
  zone hues).
- **Watch-links in the parent's recursive.eco account** (Fernando wants this):
  today it's localStorage-only. Clean path = a Launchpad page INSIDE
  flow.recursive.eco (session cookie available, account-backed storage) — an
  eco code change, so it waits for her unmerged changes to land. Interim
  no-code option if wanted: a personal private grammar "Our Watch List"
  (items = movies, metadata.watch_url), edited in the studio, read by the
  extension via the gpt token. Do NOT store family watch URLs in commons
  grammars.
- **kids-stories channel merge question**: see decision below.

## Build steps (next session)

1. **New public repo** `PlayfulProcess/movie-companions` (or fold into a
   `family-film-club` umbrella — decide with Fernando). Contents:
   - `extension/` — the whole movie-companion extension source (AGPL like
     recursive-recording? decide; content CC-BY-SA).
   - `grammars/moana/grammar.json` — exported from grammar 2a0b8085
     (repo-canonical from then on).
   - `docs/` or root `index.html` — homepage (GitHub Pages): what it is,
     extension download (zip of extension/), book links, IP/noncommercial
     statement, course link. Follow kali-paradevi gotcha: Pages source
     main/docs vs root — pick ONE and keep assets consistent.
   - Zip for download: generate `movie-companion.zip` from extension/ at
     build time or commit it; no tokens/secrets in the zip (token lives only
     in user's chrome.storage — verify before zipping).
2. **Publish the Moana grammar** (ASK FIRST) or export→repo and treat repo as
   canonical. Wire channel-level sync like nara/kali channels
   (private-repo sync pattern; webhook convergence was verified on
   bus-passengers Aug 11).
3. **Channel on recursive.eco**: needs a `tools` table INSERT (no MCP tool for
   channel creation — memory `recursive-eco-channel-submission-mcp-gap`,
   kids channel slug pattern `kids-stories`). Slug idea: `movie-companions`
   or `family-film-club`. NO eco code changes until Fernando's unmerged
   changes land (his warning Aug 11).
4. **Course** — "Make your own Movie Companion" following the tarot course
   pattern (course-viewer.html?grammar_id=...). A course IS a grammar; author
   it as one. Lessons sketch:
   L1 What a pause-point grammar is (item = pause; time/lens/quiz metadata).
   L2 Copy an existing one (import_grammars / duplicate, or fork the repo file).
   L3 Find your timestamps (extension popup "Grab current movie time").
   L4 Write good cards (kid question registers: insight/wonder/move; ALL CAPS
      short lines; no dialogue/lyrics — IP line verbatim from CLAUDE.md).
   L5 Lenses/themes (discussion/repair/legends + invent your own).
   L6 Offer to the commons (channel submission; CC-BY-SA; attribution).
5. **KPDH + Frozen grammars** — one grammar per movie (decision made Aug 11),
   same 3-lens pattern; seed as empty or starter sets; drafts stay private
   until Fernando approves each.
6. **Regenerate bundled prompt JSONs from grammars** (small script, e.g.
   `scripts/grammar-to-prompts.mjs`) so extension zip ships current content.

## Open decisions for Fernando

- Repo name/umbrella: `movie-companions` vs `family-film-club` (book links +
  bedtime-storybook.html could live under the umbrella too).
- Publish Moana grammar now vs repo-only.
- License split for extension code (AGPL vs MIT) — content is CC-BY-SA-4.0.
- Channel slug + whether kids-stories channel should cross-link.
